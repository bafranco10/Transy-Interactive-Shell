//this will be implementation#include <time.h>
using namespace std;
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "tish.h"

Tish::Tish(void) { }
Tish::~Tish(void) { }
// takes start time as parameter then it will return the difference between current and start time
int Tish::tishTime (int time_t) {
  int currentTime;
  currentTime = time(NULL);
  int totalTime;
  totalTime = currentTime - time_t;
  return totalTime;
}

// prints information on how to use commands
void Tish::printHelp() {
  cout << "help -- prints out a helpful how to"<<endl << "exit -- exits the shell" <<endl 
  <<"tishtime -- print out how long the shell has been running in seconds" << endl 
  << "lines -- how many lines have been entered by the user" << endl << 
  " lastcom -- execute the last command again" << endl 
  << " maxprocesses -- maximum number of child processes" 
  << endl << " pagesize -- system page size in bytes" 
  << endl << " cwd pid -- tell the current working directory of the indicated process" 
  << endl << "size pid -- size of the the process in pages" << 
  endl << " pstate pid -- tell the current state of the indicated process" 
  << endl << "parent pid -- return the parent pid of the indicated process" << endl;
}


