// Proc.h
//Interface
//Brian Franco

#ifndef PROC_H
#define PROC_H
#include <string.h> 
//add constructors destructors 
class Proc {
 public:
  Proc(void);
  ~Proc(void);

    string checkProcCommand(string input, bool &procCommand);
    string getPID(string UserInput);
    string getPIDSize(string UserInput);
    string getPIDStatusAndParent(string userInput);
    string getPIDCwd(string userInput);
    string getFilePath(string pid);
    string readLineByNumber(const string& filePath, int lineNumber);

 private:
  //idk yet
};
#endif
