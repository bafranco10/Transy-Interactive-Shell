//Proc Implementation 
//Brian Franco

using namespace std;
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "proc.h"
#include <fstream>

Proc::Proc(void) { }
Proc::~Proc(void) { }
// takes in the userInput and the length of the string 
// it then starts after the space and returns the pid of the command
string Proc::getPIDCwd(string userInput) {
  string pid = "";
    for (int j = 4; j < userInput.length(); j++)
      {
        pid = pid + userInput[j];
      }
      return pid;
}
// takes in the userInput and the length of the string 
// it then starts after the space and returns the pid of the command
string Proc::getPIDSize(string userInput){
  string pid = "";
   for (int j = 5; j < userInput.length(); j++)
      {
        pid = pid + userInput[j];
      }
      return pid;
}
// takes in a pid for status of the process
// returns the file path for that file
string Proc::getFilePath(string pid){
  string filePath = "/proc/" + pid + "/status";
  return filePath;
}
// takes in the userInput and the length of the string 
// it then starts after the space and returns the pid of the command
string Proc::getPIDStatusAndParent(string userInput){
  string pid = "";
   for (int j = 7; j < userInput.length(); j++)
      {
        pid = pid + userInput[j];
      }
      return pid;
}
// take in a line number and return the line it is asked for  
string Proc::readLineByNumber(const string& filePath, int lineNumber) {
  ifstream inFile(filePath);
   if (!inFile.is_open()) {
      return "File did not open";
    }
    string line; 
    int currentLineNumber = 0;
    while(getline(inFile, line)) {
      currentLineNumber++;
      if(currentLineNumber == lineNumber) {
        inFile.close();
        return line;
      }
    }
    
    inFile.close();
    return "line not found";
}
// checks what proc command I am using and then returns the value of proc command 
  string Proc::checkProcCommand(string input, bool& procCommand)
  {
    string output = "";
    for (int j = 0; j < input.length(); j++)
    {
      output = output + input[j];
      if (output == "cwd")
      {
        procCommand = true;
        j = input.length();
      }
      else if (output == "size")
      {
        procCommand = true;
        j = input.length();
      }
      else if (output == "pstate")
      {
        procCommand = true;
        j = input.length();
      }
      else if (output == "parent")
      {
        procCommand = true;
        j = input.length();
      }
      else
      {
        procCommand = false;
      }
    }
    return output;
  }