//Main implementation
using namespace std;
#include <time.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include "tish.h"
#include <unistd.h>
#include <limits.h>
#include <fstream>
#include <sys/types.h>
#include <sys/wait.h>
#include "proc.h"
//declare system calls 
int tishTime(int time_t);
ssize_t readlink(const char *pathname, char *buf, size_t bufsiz);
//global boolean value
bool procCommand;
int main(void)
{
  //initalize vars and classes
  ifstream procFile;
  Tish tish;
  Proc proc;
  procCommand = false;
  string userInput;
  int startTime;
  int lines;
  string previousCommand;
  int commandCount;
  string pid = "";
  
  //get time at beginning and userinput
  startTime = time(NULL);
  cout << "kmoorman@TISH:~$";
  getline(cin, userInput);
  lines = 0;
  commandCount = 0;
  // infinite loop that breaks with exit
  while (true)
  { 
    if (userInput == "lastcom")
    {
      if (previousCommand == "") {
        cout << "No previous command to execute" << endl;
      }
      else {
        userInput = previousCommand; 
      }
    }

  // check if its a proc command and if it is then store the value of output into procOutput
    string procOutput = proc.checkProcCommand(userInput,procCommand);

    if (procOutput == "cwd" && procCommand == true)
    {
      //get pid 
       pid = proc.getPIDCwd(userInput);
      //create full proc string 
      string procCwdPath = "/proc/" + pid + "/cwd";
      char buffer[PATH_MAX];
      ssize_t dir = readlink(procCwdPath.c_str(), buffer, PATH_MAX - 1);

      //if value is invalid then print error
      if (dir == -1) {
        cout << "Could not get current working directory of " << pid <<endl;
      } 
      //print working dir
      else {   
	      buffer[dir] = '\0'; // Null-terminate the buffer
	      cout << "Working Directory: " << buffer << endl;
      }
    }

    //if we want size then read specific line in the file 
    else if (procOutput == "size" && procCommand == true)
     {
       //get pid
        pid = proc.getPIDSize(userInput);
        string filePath = proc.getFilePath(pid);
        int lineNumber = 18;
        //give 
        string stateLine = proc.readLineByNumber(filePath,lineNumber);
        cout << stateLine <<endl;
    }

    // if pstate is what we want read line 3 in the file and return line
    else if (procOutput == "pstate" && procCommand == true)
    {
      pid = proc.getPIDStatusAndParent(userInput);
      string filePath = proc.getFilePath(pid);
      int lineNumber = 3;
      string stateLine = proc.readLineByNumber(filePath,lineNumber);
      cout << stateLine << endl; 
    }

    // if parent is what we want read line 7 in the file and return line
    else if (procOutput == "parent" && procCommand == true)
    {
      pid = proc.getPIDStatusAndParent(userInput);
      string filePath = proc.getFilePath(pid);
      int lineNumber = 7;
      string stateLine = proc.readLineByNumber(filePath,lineNumber);
      cout << stateLine <<endl;
    }

    else if (userInput == "tishtime")
    {
      int totalTime = tish.tishTime(startTime);
      cout << totalTime <<" seconds" <<endl;
    }

    else if (userInput == "maxprocesses")
    {
      long int maxChildProcesses = sysconf(_SC_CHILD_MAX);
      cout << maxChildProcesses << " Child Processes" << endl;
    }

    else if (userInput == "pagesize")
    {
      long int pageSize = sysconf(_SC_PAGESIZE);
      cout << "Page size = " << pageSize << " bytes" << endl;
    }
   
    else if (userInput == "help")
    {
      tish.printHelp();
    }

    else if (userInput == "lines")
    {
      cout << lines << endl;
    }

    //logic for external commands fork if command is not inside of tish
    //it will only work with no spaces
    else if (userInput != "exit" || userInput != "exit "){
      pid_t pid = fork();
	    if (pid < 0) {
        cerr << "Fork Failed" <<endl; 
        return 1;
	    }
	    else if (pid == 0) {
      string directory = "/bin/" + userInput; 
	    execl(directory.c_str(),userInput.c_str(),NULL);
      exit(1);
	    } 
	    else {
	    wait(NULL);
	    }
    }

    //exit loop
    if (userInput == "exit" || userInput == "exit ") {
      break;
    }

   //store  old inputs and reprompt user
    previousCommand = userInput;
    cout << "kmoorman@TISH:~$:";
    getline(cin, userInput);
    lines++;
  }
  return 0;
}
