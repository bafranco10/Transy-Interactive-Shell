// Tish.h
//Interface
//Brian Franco

#ifndef TISH_H
#define TISH_H
#include <string.h> 
//add constructors destructors 
class Tish {

 public:
  Tish(void);
  ~Tish(void);

  int tishTime(int time_t);
  void printHelp(void);

 private:
};
#endif
